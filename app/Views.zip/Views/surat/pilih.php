<?= $this->extend('layout/admin') ?>
<?= $this->section('content') ?>

<div class="d-flex align-items-center gap-2 mb-3">
    <div>
        <h5 class="mb-0 fw-bold">Cetak Surat Keterangan</h5>
        <small class="text-muted">Pilih warga dan jenis surat yang akan dicetak</small>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header d-flex align-items-center gap-2">
                <i class="bi bi-envelope-paper text-warning"></i> Form Penerbitan Surat
            </div>
            <div class="card-body">
                <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div>
                <?php endif; ?>

                <form action="<?= site_url('surat/cetak') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Nama Warga (NIK / Nama) <span class="text-danger">*</span></label>
                        <select name="penduduk_id" class="form-select" required>
                            <option value="">-- Pilih Warga --</option>
                            <?php foreach ($penduduk as $p): ?>
                            <option value="<?= $p['id'] ?>">
                                <?= esc($p['nama_lengkap']) ?> — <?= esc($p['nik']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Ketik untuk mencari nama atau NIK.</div>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Jenis Surat <span class="text-danger">*</span></label>
                        <?php if (empty($jenisSurat)): ?>
                            <div class="alert alert-warning mb-0">
                                <i class="bi bi-exclamation-triangle me-1"></i>
                                Belum ada jenis surat terdaftar. Tambahkan melalui database.
                            </div>
                        <?php else: ?>
                        <div class="row g-2">
                            <?php foreach ($jenisSurat as $js): ?>
                            <div class="col-md-6">
                                <label class="d-flex align-items-center gap-2 p-3 border rounded cursor-pointer surat-option">
                                    <input type="radio" name="jenis_surat_id" value="<?= $js['id'] ?>" required>
                                    <div>
                                        <div class="fw-semibold small"><?= esc($js['nama_surat']) ?></div>
                                        <div class="text-muted" style="font-size:.72rem">Kode: <?= esc($js['kode_surat']) ?></div>
                                    </div>
                                </label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="alert alert-info small">
                        <i class="bi bi-info-circle me-1"></i>
                        Nomor surat akan dibuat otomatis berdasarkan urutan dan tahun berjalan.
                        Setiap klik <strong>Cetak</strong> akan mencatat surat ke dalam log.
                    </div>
                    <div class="d-grid">
                        <button type="submit" class="btn btn-warning btn-lg" <?= empty($jenisSurat) ? 'disabled' : '' ?>>
                            <i class="bi bi-printer me-1"></i> Generate & Cetak Surat
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->section('scripts') ?>
<style>
.surat-option { cursor: pointer; transition: background .15s; }
.surat-option:has(input:checked) { background: #e8f5e9; border-color: #2d7a56 !important; }
.surat-option:hover { background: #f8f9fa; }
</style>
<?= $this->endSection() ?>
<?= $this->endSection() ?>
