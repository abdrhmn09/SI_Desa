<?= $this->extend('layout/admin') ?>
<?= $this->section('content') ?>

<div class="d-flex align-items-center gap-2 mb-3">
    <a href="<?= site_url('pemerintahan') ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i></a>
    <div>
        <h5 class="mb-0 fw-bold"><?= esc($title) ?></h5>
    </div>
</div>

<?php if (!empty($errors)): ?>
<div class="alert alert-danger"><ul class="mb-0 ps-3"><?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card">
            <div class="card-body">
                <form action="<?= site_url('pemerintahan/update/'.$struktur['id']) ?>" method="post" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Jabatan <span class="text-danger">*</span></label>
                        <input type="text" name="nama_jabatan" class="form-control"
                            value="<?= old('nama_jabatan', $struktur['nama_jabatan']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Pejabat <span class="text-danger">*</span></label>
                        <input type="text" name="nama_pejabat" class="form-control"
                            value="<?= old('nama_pejabat', $struktur['nama_pejabat']) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tahun / Periode <span class="text-danger">*</span></label>
                        <input type="text" name="tahun" class="form-control"
                            value="<?= old('tahun', $struktur['tahun']) ?>" required>
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold">Foto</label>
                        <?php if (!empty($struktur['foto'])): ?>
                        <div class="mb-2 d-flex align-items-center gap-2">
                            <img src="<?= site_url('uploads/pemerintahan/'.$struktur['foto']) ?>"
                                class="rounded-circle" style="width:60px;height:60px;object-fit:cover">
                            <span class="text-muted small">Foto saat ini</span>
                        </div>
                        <?php endif; ?>
                        <input type="file" name="foto" class="form-control" accept="image/jpeg,image/png,image/webp">
                        <div class="form-text">Kosongkan jika tidak ingin mengganti foto.</div>
                    </div>
                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-warning"><i class="bi bi-save me-1"></i> Perbarui</button>
                        <a href="<?= site_url('pemerintahan') ?>" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
